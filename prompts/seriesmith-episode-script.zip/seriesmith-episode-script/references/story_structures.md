# Story structures

A reference for SKILL.md: the major story structures, for outlining an episode
written from scratch.

The beat percentages are guides for timing, not rules. Multiply them by the episode's
runtime to estimate each beat's screen time, and so how many shots it gets.

---

## Quick selector

| Structure | Core engine | Ends with | Best runtime | Episodic fit |
|---|---|---|---|---|
| Hero's Journey | External quest that changes the hero | Hero returns home changed, with something to share | Long (feature, season arc) | Season arc; too big for one short episode |
| Virgin's Promise | Inner discovery of the true self | Community changed by the hero being herself | Medium–long | Season arc or character-focused episode |
| Three-Act / Change Arc | Goal + obstacles + a low point | Victory (or a meaningful loss) earned through growth | Any | Strong standalone episodes |
| Sitcom / Circular | A problem spirals into chaos, then is fixed | Back to the exact starting point | Short–half-hour | Built for it |
| Dan Harmon's Story Circle | Want → get it → pay for it | Back home, but changed | Short–half-hour | Built for it |
| Kishōtenketsu | Contrast and a surprising turn, not conflict | A new understanding from combining the turn with the setup | Very short–medium | Quiet, reflective, slice-of-life episodes |
| Fable | A flaw meets its consequence | A moral, often stated outright | Very short | Bedtime / children's episodes |
| Parable | Everyday situation with a deeper meaning | A truth the audience has to recognize | Short | Anthology or ethics-driven episodes |
| Cautionary Tale | A warning ignored | Punishment | Very short–short | Horror, children's, anthology |
| Freytag's Pyramid | Rise to a central turning point, then the fall | Resolution or tragic catastrophe | Medium–long | Prestige drama, tragedy |
| Fichtean Curve | Crisis after rising crisis | An explosive climax and a quick ending | Any | Thrillers, action, cliffhanger serials |
| In Medias Res | Open on the crisis, rewind to explain | The opening moment, finally understood, then the finale | Any | A strong cold-open hook |
| Pixar Story Spine | A routine broken, with a chain of cause and effect | A new normal | Very short–short | Bedtime / children's, quick outlines |

---

## Asking the user (menu)

When someone starts an episode from scratch and hasn't named a structure, offer a short
menu like this one, in the same message as the questions in AUTHORING's **Starting a
series** (when the series is new). Describe the *shape* of each option and give one familiar
example. Then ask the two follow-ups at the end.

> **What kind of story shape do you want for this episode?**
> 1. **Big transformation (Hero's Journey)**: someone leaves their normal life, faces a huge trial and comes back changed. *Star Wars, The Lion King.*
> 2. **Finding yourself (Virgin's Promise)**: someone secretly becomes who they really are, and everyone around them is better for it. *Billy Elliot, Frozen.*
> 3. **Classic three-act**: a goal, rising obstacles, a darkest moment and a hard-won climax. *Most films.*
> 4. **Reset comedy (Sitcom)**: a small problem snowballs into chaos, gets fixed and everything goes back to normal. *Seinfeld, Friends.*
> 5. **Story Circle**: someone wants something, gets it, pays for it and comes home a little different. *Rick and Morty, Community.*
> 6. **Quiet twist (Kishōtenketsu)**: no villain; a calm setup, then an unexpected turn that changes how you see it. *My Neighbor Totoro.*
> 7. **Fable**: a character's flaw leads straight to its consequence, and there's a lesson at the end. *The Tortoise and the Hare.*
> 8. **Parable**: an everyday human situation that carries a deeper moral meaning. *The Good Samaritan.*
> 9. **Cautionary tale**: someone ignores a warning, enjoys it for a while, then pays. *The Boy Who Cried Wolf, Gremlins.*
> 10. **Five-act drama (Freytag)**: rising action, a central turning point, then the fall. *Macbeth, Romeo and Juliet.*
> 11. **Nonstop escalation (Fichtean Curve)**: start straight in trouble, with each crisis bigger than the last. *Mad Max: Fury Road.*
> 12. **Start at the end (In Medias Res)**: open on the crisis, then jump back to show how we got there. *Breaking Bad pilot, Sunset Boulevard.*
> 13. **Story Spine**: "Once upon a time… every day… until one day…" A simple chain of cause and effect. *Most Pixar shorts.*
>
> Follow-ups: *About how long should the episode be?* and *Is this a standalone story, or part of a longer arc?*

If they aren't sure, suggest a structure from the tone and length they want (see
**Choosing by need** at the end). If they'd rather you just start, pick one, say which and
why in a line, and go on.

---

## From beats to shots

An outline is beats; a script is shots. A structure not listed here (one the person names)
works the same way: outline its beats, give each a share of the runtime, and the rules below
turn them into shots. Going from one to the other:

- **Count the shots.** A beat's share of the runtime, divided by the length of a typical
  shot (3 to 4 s; dialogue shots run longer, inserts shorter), is roughly how many shots it
  gets. A 3-minute episode is around 50 shots: a 10% beat is about 18 s, five shots or so.
- **Merge beats that come out under a shot or two.** A 12-stage Hero's Journey in a
  2-minute episode leaves several stages one shot each: combine them (the notes under each
  structure say which), or pick a shorter structure. For 1 to 3 minutes, the Fable, the
  Story Spine, Kishōtenketsu, the Story Circle and the Cautionary Tale fit best.
- **Mark the beats in the script** with a comment above each beat's first shot, so the
  outline survives into the script and the next edit can see it. The build ignores them:

  ```
  // Inciting Incident
  ## sh060
  ```

- **A beat is not a sequence.** A `#` sequence is a place; a beat can run across several of
  them, or share one with the next beat.
- **Every beat has to be on screen.** Each shot is rendered by a model with no memory of the
  others (AUTHORING's **The one thing that shapes every decision**), and an audience sees
  only what's in the picture and the sound. Inner beats (the Debate, the Dark Night of the
  Soul, Recognition, Power Within) need an action, a look held long enough to read, or a
  line: write "Mara puts the letter face down and stares at the wall", not "Mara realizes
  she was wrong". A narrator (`NAME (V.O.): line`) suits the Fable's moral and the Story
  Spine's "once upon a time".
- **Mirrored images are a framing choice.** The Three-Act's final image and the Story
  Circle's return mirror the opening: put them in the same location with the same `size:`
  and a matching `camera:`, so the plate and the framing do the rhyming.
- **Time jumps need a marker.** For In Medias Res or a flashback, put a card on screen
  (`target: hold` with a picture of "Three days earlier") or change the look unmistakably,
  so the viewer doesn't get lost.
- **A season arc lives outside the scripts.** When a long structure (Hero's Journey,
  Virgin's Promise, the 27 beats) runs across a season, keep the arc in the outline. Each
  episode still has its own shape, and the people and places it shares with the others come
  from `series.json`.

---

## 1. Mythic & transformational

These structures follow a deep change in one protagonist, who is forced out of their comfort
zone and grows.

### 1.1 The Hero's Journey (Monomyth)

**Origin:** Joseph Campbell, *The Hero with a Thousand Faces* (1949), condensed into 12
stages by Christopher Vogler, *The Writer's Journey*.

**Pitch:** A hero leaves the ordinary world, enters an unfamiliar (often supernatural)
realm, survives a supreme ordeal, wins a reward and comes home changed, bringing back
something that helps others.

**Best for:** Epic adventures, coming-of-age stories, fantasy and sci-fi, and season-long or
multi-episode arcs.

**Beats (Vogler's 12 stages):**

| # | Beat | What happens | ~% |
|---|---|---|---|
| 1 | **Ordinary World** | Show the hero's normal life, their flaw or lack, and what's at stake if nothing changes. | 0–10 |
| 2 | **Call to Adventure** | A problem, challenge or message disrupts the ordinary world. | 10 |
| 3 | **Refusal of the Call** | The hero hesitates out of fear, duty or doubt. This shows the cost of going. | 10–15 |
| 4 | **Meeting the Mentor** | A guide gives advice, training, a gift or the confidence to go. | 15–20 |
| 5 | **Crossing the Threshold** | The hero commits and enters the special world. There's no easy way back. | 20–25 |
| 6 | **Tests, Allies, Enemies** | The hero learns the new world's rules, makes friends and enemies, and faces smaller trials. | 25–45 |
| 7 | **Approach to the Inmost Cave** | The team prepares to face the central danger. Tension and stakes build. | 45–50 |
| 8 | **The Ordeal** | The central crisis: a brush with death (literal or symbolic) and the greatest fear faced. | 50–60 |
| 9 | **Reward (Seizing the Sword)** | Having survived, the hero claims the prize: an object, knowledge or reconciliation. | 60–70 |
| 10 | **The Road Back** | The hero heads home, but the consequences follow. Often there's a chase or a new threat. | 70–80 |
| 11 | **Resurrection** | A final, higher-stakes test where the hero must use everything they've learned. They are purified and reborn. | 80–95 |
| 12 | **Return with the Elixir** | The hero comes home changed, with something that heals or improves the ordinary world. | 95–100 |

**Example:** *Star Wars: A New Hope*: Tatooine → Leia's message → Luke refuses → Obi-Wan →
leaving Tatooine → the cantina and the Falcon → the Death Star → the trash compactor and
Obi-Wan's death → rescuing Leia → escape and pursuit → the trench run → the medal ceremony.

**Pitfalls:**
- Running all 12 stages in a short episode makes every beat thin. For shorts, merge stages
  (1+2, 3+4, 9+10) or use the Story Circle instead.
- A mentor who solves the problem for the hero. The hero has to win the Ordeal and the
  Resurrection themselves.
- A Return that skips the "elixir". The change should be visible back in the ordinary world.

#### The 27 beats: the journey at length

For a season, or an episode long enough to need finer steps, the journey can be outlined as
27 beats: three acts of nine, each act three blocks of three (a setup, a conflict and a
resolution). Each beat is about 3.7% of the runtime; across a season of nine episodes, each
episode can take one block. Vogler's stages are in brackets.

| Act | # | Beat | What happens |
|---|---|---|---|
| **One** | 1 | **Intro** | The hero's ordinary world, and the flaw or lack they carry. [Ordinary World] |
| | 2 | **Inciting Incident** | The event that breaks it. [Call to Adventure] |
| | 3 | **Immediate Reaction** | The first, instinctive response: shock, denial, a joke. [Refusal] |
| | 4 | **Reaction** | The considered response: what they think they should do about it. |
| | 5 | **Action** | They act on that, usually the small or safe way. |
| | 6 | **Consequence** | The result raises the stakes: the small way doesn't work. |
| | 7 | **Pressure** | Staying put stops being possible. A mentor or ally often pushes here. [Mentor] |
| | 8 | **Pinch** | The opposing force shown directly, so its threat is real. |
| | 9 | **Push** | The final shove: the hero commits and goes. [Crossing the Threshold] |
| **Two** | 10 | **New World** | The new place or situation, and its rules. |
| | 11 | **Fun & Games** | The premise enjoyed: the hero tries things, wins some, meets friends and enemies. [Tests, Allies, Enemies] |
| | 12 | **Old Contrast** | A reminder of the old world or old self: what has changed, or what they miss. |
| | 13 | **Build Up** | Moving toward the central goal; the stakes climb. [Approach] |
| | 14 | **Midpoint** | A revelation or event that turns the hero from reacting to acting. [Ordeal] |
| | 15 | **Reversal** | The midpoint's consequence turns things against them. |
| | 16 | **Reaction** | The hero takes in the reversal. |
| | 17 | **Action** | A new plan, taken. [Reward] |
| | 18 | **Dedication** | Full commitment, the cost accepted. [The Road Back] |
| **Three** | 19 | **Trials** | The plan meets resistance and things go wrong. |
| | 20 | **Pinch** | The opposing force's second direct blow. |
| | 21 | **Darkest Point** | All seems lost. |
| | 22 | **Power Within** | The hero finds the strength or insight they lacked: the flaw from beat 1, faced. |
| | 23 | **Action** | They act on it, with a new plan. |
| | 24 | **Converge** | Every thread and character comes together for the end. |
| | 25 | **Battle** | The final confrontation. [Resurrection] |
| | 26 | **Climax** | The decisive moment the battle turns on. |
| | 27 | **Resolution** | The new ordinary world, and what the hero brought back. [Return with the Elixir] |

The two Pinches (8 and 20) and the Midpoint (14) are what keep a long middle from sagging:
plan them first, then fill the beats between.

---

### 1.2 The Virgin's Promise

**Origin:** Kim Hudson, *The Virgin's Promise* (2009). "Virgin" is meant in the archetypal
sense of someone self-possessed and not defined by others. It isn't about gender or
sexuality, and the protagonist can be anyone.

**Pitch:** Where the hero goes outward to conquer, this protagonist goes inward to become who
they truly are. They find their gift, nurture it in secret, are found out, choose themselves
anyway, and the community that resisted is better for it.

**Best for:** Character-driven drama, artist or identity stories, family stories, and quiet
protagonists in a restrictive world.

**Beats (Hudson's 13):**

| # | Beat | What happens | ~% |
|---|---|---|---|
| 1 | **Dependent World** | The protagonist relies on others (family, community, a system) for safety and identity. | 0–8 |
| 2 | **Price of Conformity** | Fitting in costs them their true self. Show what's being suppressed. | 8–15 |
| 3 | **Opportunity to Shine** | A chance comes to express their hidden gift or desire, often by accident. | 15–20 |
| 4 | **Dresses the Part** | They take on the trappings of the true self: a costume, a role, a secret identity. | 20–25 |
| 5 | **Secret World** | They live a double life, nurturing their gift away from the dependent world. | 25–40 |
| 6 | **No Longer Fits Her World** | The two lives grate against each other. The old world feels wrong. | 40–50 |
| 7 | **Caught Shining** | The secret is discovered, and the dependent world reacts. | 50–58 |
| 8 | **Gives Up What Kept Her Stuck** | They let go of the attachment, fear or belief that kept them conforming. | 58–65 |
| 9 | **Kingdom in Chaos** | The community is thrown into turmoil by the change. | 65–72 |
| 10 | **Wanders in the Wilderness** | Doubt and temptation to go back to safety. This is the low point. | 72–80 |
| 11 | **Chooses Her Light** | They fully commit to their true self, whatever it costs. | 80–88 |
| 12 | **Re-ordering (Rescue)** | The community reorganizes around the new reality and often comes to their aid. | 88–95 |
| 13 | **The Kingdom Is Brighter** | Everyone is better off because the protagonist became themselves. | 95–100 |

**Example:** *Billy Elliot*: a mining-town boy (Dependent World) is expected to box (Price of
Conformity), stumbles into a ballet class (Opportunity to Shine), trains in secret (Secret
World), is caught by his father (Caught Shining), goes through the strike-torn family crisis
(Kingdom in Chaos), commits to the audition (Chooses Her Light) and is backed by the town
(Re-ordering).

**Pitfalls:**
- Making the dependent world a cartoon villain. It should be loving but limiting, so the
  choice actually hurts.
- Skipping the community payoff. The defining feature is that the *world* changes, not just
  the protagonist.
- Turning it into a Hero's Journey by adding a big external enemy. The opposition is the
  pressure to conform.
- Dresses the Part (4) is a wardrobe change: a variant of the character in `series.json`
  (AUTHORING's **A wardrobe change is a new subject**), so plan it with the cast.

---

### 1.3 The Change Arc (Three-Act Structure)

**Origin:** It goes back to Aristotle's beginning, middle and end. Syd Field formalized it for
screenwriting in *Screenplay* (1979), and Blake Snyder's *Save the Cat!* refines it.

**Pitch:** A status quo is broken by an inciting incident. The protagonist pursues a goal
through rising complications, the stakes rise at the midpoint, everything collapses at the
low point ("dark night of the soul"), and the protagonist uses what they've learned to win
the climax.

**Best for:** Almost anything. It's the default for standalone episodes, films and most
drama.

**Beats:**

| Act | Beat | What happens | ~% |
|---|---|---|---|
| **I: Setup** | **Opening / Status Quo** | Show the world and the protagonist as they are, including the flaw or need. | 0–10 |
| | **Inciting Incident** | Something breaks the status quo and creates the central problem. | 10–12 |
| | **Debate** | The protagonist hesitates or weighs options. Stakes are made clear. | 12–20 |
| | **Plot Point 1 (Break into Two)** | The protagonist commits to a goal and enters a new situation. | 20–25 |
| **II: Confrontation** | **Rising Complications** | They chase the goal and meet obstacles. Often there's a B-story (relationship or theme). | 25–50 |
| | **Midpoint** | A false victory or false defeat. New information raises the stakes, and the protagonist shifts from reacting to acting. | 50 |
| | **Pressure Mounts** | The opposition closes in, alliances crack and inner flaws cause outer problems. | 50–75 |
| | **Low Point (Dark Night of the Soul)** | All seems lost. Something or someone dies, literally or symbolically. The protagonist faces the flaw. | 75 |
| **III: Resolution** | **Plot Point 2 (Break into Three)** | An insight, often from the B-story, gives a new plan. | 75–80 |
| | **Climax** | The final confrontation. The protagonist wins (or loses meaningfully) by acting as their changed self. | 80–95 |
| | **Resolution / Final Image** | The new normal, often a mirror of the opening image to show the change. | 95–100 |

**Example:** *Toy Story*: Woody is the top toy → Buzz arrives → rivalry → Woody knocks Buzz
out the window and both are lost → the gas station and Pizza Planet → Buzz learns he's a toy
(low point for Buzz) → trapped at Sid's (low point for Woody) → they work together → the
chase after the moving truck → Woody and Buzz as co-leaders.

**Pitfalls:**
- A saggy Act II. Use the midpoint to turn the story, not just to add more obstacles.
- A climax won by luck or by someone else. Win it through the change.
- Not planting the flaw in Act I, so the growth feels unearned.

---

## 2. Situational, episodic & media

These structures suit recurring formats, ensembles and fast pacing, where returning to the
status quo, or a small and repeatable change, matters.

### 2.1 The Sitcom Formula (Circular Structure)

**Origin:** Radio and TV situation comedy. It's built so a series can keep going
indefinitely.

**Pitch:** It works like a rubber band. A character makes a problem (usually by a lapse in
judgment, a lie or a scheme), the chaos snowballs, a misunderstanding peaks, and by the end
the mistake is undone. Everyone is back exactly where they started, ready for next week.

**Best for:** Comedy, ensembles, half-hour episodes and any series where the characters
shouldn't change much between episodes.

**Beats:**

| # | Beat | What happens | ~% |
|---|---|---|---|
| 1 | **Cold Open / Teaser** | A self-contained gag or a quick setup that hooks the audience and often seeds the theme. | 0–8 |
| 2 | **Status Quo** | The usual dynamics: who wants what, the running jokes and the setting. | 8–15 |
| 3 | **The Problem** | The A-plot starts with a want, a mistake or an outside disruption. A B-plot (and sometimes C) starts with other characters. | 15–25 |
| 4 | **The Bad Decision / Scheme** | Instead of the sensible fix, the character lies, covers up or schemes. | 25–35 |
| 5 | **Complications** | The scheme needs more lies. Other characters get pulled in. The B-plot starts to cross into the A-plot. | 35–65 |
| 6 | **Peak Chaos / Misunderstanding** | Everything collides, often with all the characters in one place, at the worst possible moment. | 65–80 |
| 7 | **Confession / Fix** | The truth comes out or the mistake is undone. Sometimes there's a small emotional beat. | 80–92 |
| 8 | **Reset** | Back to the status quo. The lesson is learned, or comically not learned. | 92–97 |
| 9 | **Tag** | A final callback joke after the resolution. | 97–100 |

**Example:** A typical *Seinfeld* episode: four separate small problems escalate in parallel
and collide in one absurd climax, and nobody grows.

**Pitfalls:**
- Letting the reset erase emotional moments the audience cared about. Keep a sliver of
  warmth, or lean fully into "no lessons".
- A-, B- and C-plots that never connect. The payoff comes from them colliding.
- Characters who are dumb rather than flawed. Their bad decisions should come from
  consistent traits.
- Peak Chaos with the whole cast in one shot can run past a model's picture slots: check how
  many people the shot's model takes (AUTHORING's **Choosing a video target**), or cover the
  collision in several shots.

---

### 2.2 Dan Harmon's Story Circle

**Origin:** Dan Harmon (*Community*, *Rick and Morty*), a streamlined 8-step version of the
Monomyth for episodic TV.

**Pitch:** A circle split into a top half (the ordinary world, order) and a bottom half (the
unfamiliar world, chaos). The character goes down into chaos to get what they want, pays for
it, and comes back up changed. The change can be small, which is what makes it repeatable.

**Best for:** Episodic TV, short films, and any story under about 30 minutes that still
needs a real arc. It also works at scene level.

**Beats:**

| # | Label | Beat | What happens | ~% |
|---|---|---|---|---|
| 1 | **You** | Zone of comfort | Establish the character in their familiar world. | 0–10 |
| 2 | **Need** | But they want something | A desire, lack or problem appears. | 10–20 |
| 3 | **Go** | Unfamiliar situation | They cross into somewhere, or something, new. | 20–30 |
| 4 | **Search** | Adapt to it | They struggle, learn the rules and pick up tools or allies. | 30–50 |
| 5 | **Find** | Get what they wanted | They get it, often at the midpoint, the bottom of the circle. | 50–60 |
| 6 | **Take** | Pay a heavy price | The cost hits: what they wanted wasn't what they needed, or it costs something dear. | 60–75 |
| 7 | **Return** | Back to the familiar | They come back to where they started. | 75–90 |
| 8 | **Change** | Having changed | They are different now, and can do or see something they couldn't before. | 90–100 |

**Example:** A typical *Rick and Morty* episode: Morty wants something → an adventure in
another dimension → he gets it → it goes horribly wrong → he's back home, a little more
jaded or a little wiser.

**Pitfalls:**
- Making "Find" the end. The price (step 6) is where the meaning is.
- A change that's purely external. Step 8 should be a shift in the character's
  understanding.
- Forgetting that steps 1 and 8 should visibly mirror each other.

---

### 2.3 Kishōtenketsu (Four-Act Structure)

**Origin:** Classical Chinese poetry (起承轉合, *qǐ chéng zhuǎn hé*), adopted in Japanese
(起承転結) and Korean narrative. It's the basis of four-panel *yonkoma* comics.

**Pitch:** A structure that doesn't need conflict. Rather than a protagonist beating an
opponent, it builds on contrast and revelation. The story is set up and developed, then
something unexpected (and seemingly unrelated) appears, and the ending reconciles the two to
give a new understanding.

**Best for:** Slice-of-life, quiet or contemplative pieces, children's stories without
villains, poetry-like shorts and gentle twists.

**Beats:**

| # | Beat | What happens | ~% |
|---|---|---|---|
| 1 | **Ki (起): Introduction** | Establish the characters, setting and situation. Calm, observational. | 0–25 |
| 2 | **Shō (承): Development** | Deepen and expand the introduction without any big change. More texture, routine and detail. | 25–50 |
| 3 | **Ten (転): Twist** | An unexpected element or a big shift in perspective. It may seem unrelated at first. | 50–75 |
| 4 | **Ketsu (結): Conclusion** | Link the twist back to the premise. The resolution comes from combining the two, not from defeating someone. | 75–100 |

**Example:** *My Neighbor Totoro*: a family moves to the countryside (Ki) → everyday life,
exploring and settling in (Shō) → the forest spirits appear, and later Mei goes missing
(Ten) → the spirits help, the family reunites, and the world is seen with new wonder
(Ketsu). In four comic panels: a girl waits at a bus stop in the rain → she waits longer and
gets soaked → a stranger walks by holding two umbrellas → he hands her one, and he's her
father, who came to meet her.

**Pitfalls:**
- Sneaking in a villain to manufacture tension. Trust the contrast.
- A twist that's just random. It has to recontextualize the setup.
- A long Shō with no texture. The development should still be interesting to watch: vary the
  sizes and the camera from shot to shot.

---

## 3. Moral, allegorical & folk

These are historical structures for delivering a lesson, a thematic truth or a cultural
warning through tight, symbolic plotting.

### 3.1 The Fable (Aesop's Formula)

**Origin:** Aesop (ancient Greece), later La Fontaine and the Panchatantra.

**Pitch:** A tightly compressed structure. Its characters are usually animals or objects,
each embodying one human trait (pride, greed, laziness). The story moves straight from the
flaw to an immediate, often ironic consequence and ends with an explicit moral.

**Best for:** Bedtime and children's stories, very short episodes, and any piece where a
clear lesson is the point.

**Beats:**

| # | Beat | What happens | ~% |
|---|---|---|---|
| 1 | **Character & Trait** | Introduce the character and their defining flaw or virtue quickly, often through a single action or line. | 0–15 |
| 2 | **Situation / Temptation** | A situation that tests the trait: a contest, a find or an encounter. | 15–35 |
| 3 | **The Choice** | The character acts in line with their flaw. | 35–60 |
| 4 | **Consequence** | The result follows immediately and is often ironic. The flaw backfires (or the virtue pays off). | 60–85 |
| 5 | **Moral** | The lesson, stated outright by a narrator or a character ("Slow and steady wins the race"). | 85–100 |

**Example:** *The Tortoise and the Hare*: the boastful Hare challenges the Tortoise → the
race → the Hare naps because he's overconfident → the Tortoise wins → "Slow and steady wins
the race."

**Pitfalls:**
- More than one flaw or theme. A fable makes one point.
- A consequence that doesn't follow directly from the trait. It should feel inevitable and
  fitting.
- A moral that preaches beyond what the story actually showed.

---

### 3.2 The Parable

**Origin:** Religious and wisdom-literature traditions (the Gospels, Buddhist sutras, Sufi
and Zen teaching stories).

**Pitch:** Like a fable, but with human characters in realistic, everyday situations. The
surface story is ordinary; the meaning underneath is spiritual, ethical or philosophical.
The lesson is often left for the audience to recognize, and it usually overturns an
expectation.

**Best for:** Ethics-driven drama, anthology episodes, stories about kindness, judgment or
moral courage, and grounded realism with a message.

**Beats:**

| # | Beat | What happens | ~% |
|---|---|---|---|
| 1 | **Ordinary Situation** | A recognizable, everyday setting: work, family, a road, a field. | 0–20 |
| 2 | **Expected Pattern** | Set up who the audience *expects* to act well or badly, or how things "should" go. | 20–40 |
| 3 | **The Test** | Someone in need, a choice or an opportunity appears. | 40–60 |
| 4 | **The Reversal** | The unlikely person does the right thing, or the expected one fails. | 60–85 |
| 5 | **Recognition** | The meaning lands, through a closing question, a quiet image or the consequence. It's rarely stated outright. | 85–100 |

**Example:** *The Good Samaritan*: a traveler is beaten and left by the road → a priest and
a Levite (the expected helpers) pass by → a Samaritan (the despised outsider) stops and
cares for him → "Which of these was a neighbor?"

**Pitfalls:**
- Spelling out the meaning. A parable trusts the audience.
- Characters who are just symbols. Keep them human and plausible.
- No reversal. Without a subverted expectation, it's just an anecdote.

---

### 3.3 The Cautionary Tale

**Origin:** Folk tradition: European folktales, *Struwwelpeter* (1845), Hilaire Belloc's
*Cautionary Tales for Children*, and modern horror and urban legends.

**Pitch:** A plain story designed as a warning. A character breaks a clear rule, taboo or
warning, enjoys a short stretch of success or thrills, and is then met with swift and often
severe punishment that serves as an example.

**Best for:** Horror, dark comedy, children's warnings, anthology episodes (*Twilight Zone*,
*Black Mirror* style) and morality plays.

**Beats:**

| # | Beat | What happens | ~% |
|---|---|---|---|
| 1 | **The Rule / Warning** | State the rule clearly: from a parent, a sign, an elder or a strange shopkeeper. | 0–15 |
| 2 | **The Temptation** | Show why breaking it is appealing. | 15–25 |
| 3 | **The Transgression** | The character breaks the rule, often casually or defiantly. | 25–35 |
| 4 | **The Thrill** | At first it pays off. Fun, gain, power. The audience is lulled. | 35–60 |
| 5 | **Warning Signs** | Small hints that something is wrong. They're ignored. | 60–75 |
| 6 | **The Punishment** | A swift, fitting and often disproportionate consequence. | 75–95 |
| 7 | **The Example** | A final image or line that turns the character into a warning for others. | 95–100 |

**Example:** *Gremlins*: three rules (no bright light, no water, never feed after midnight)
→ a cute pet → the rules are broken → chaos → a town in ruins and the pet taken back. *The
Boy Who Cried Wolf* is the children's version.

**Pitfalls:**
- Not establishing the rule clearly up front. The audience must know it was broken: say it
  in a line, or show it (a sign in an insert).
- A punishment that doesn't fit the crime thematically. Poetic justice is what makes it
  satisfying.
- Too much sympathy without a payoff. Decide whether the tone is grim, darkly comic or
  tragic.

---

## 4. Structural geometry & plot-driven shapes

These structures are defined by the shape of the tension curve or by rearranging the
timeline.

### 4.1 Freytag's Pyramid (Five-Act Structure)

**Origin:** Gustav Freytag, *Die Technik des Dramas* (1863), based on classical Greek and
Shakespearean drama.

**Pitch:** A strict, symmetrical shape. The action rises to a climax in the *middle*, the
turning point where the protagonist's fortunes reverse, then falls to a denouement that ends
in either catastrophe (tragedy) or resolution.

**Best for:** Tragedy, prestige drama, rise-and-fall stories (crime, ambition, hubris) and
stories where the second half shows the fallout.

**Beats:**

| # | Beat | What happens | ~% |
|---|---|---|---|
| 1 | **Exposition** | The world, characters and tensions. It ends with the *exciting force* (the inciting incident). | 0–20 |
| 2 | **Rising Action** | Complications build. The protagonist pursues the goal and tension climbs. | 20–45 |
| 3 | **Climax (Turning Point)** | The peak at the center: the decisive action that turns the protagonist's fortune. | 45–55 |
| 4 | **Falling Action** | The consequences unfold and opposing forces gain ground. It includes a *moment of final suspense*, where the outcome seems briefly in doubt. | 55–85 |
| 5 | **Denouement** | The final outcome: **catastrophe** (the tragic fall) or **resolution** (order restored). | 85–100 |

**Example:** *Macbeth*: the witches' prophecy (exposition) → the murder of Duncan and the
rise to power (rising action) → Banquo's murder and Fleance's escape (the turning point) →
the descent into paranoia and the gathering opposition (falling action) → Birnam Wood,
Macduff and Macbeth's death (catastrophe).

**How it differs from three-act:** In three-act the climax comes near the end. In Freytag
it's in the middle, and the second half is about the consequences.

**Pitfalls:**
- A flat second half. The falling action still needs tension (the "moment of final
  suspense").
- A climax that's just a big event. It must *reverse* the protagonist's direction.

---

### 4.2 The Fichtean Curve

**Origin:** Described by John Gardner in *The Art of Fiction* (1983), and named after the
philosopher Johann Gottlieb Fichte. It's common in thrillers, pulp and short fiction.

**Pitch:** A high-intensity shape that skips the long setup. It drops characters straight
into the inciting crisis, then delivers a rapid series of crises, each bigger than the last,
separated by brief breathers, until a final, explosive climax. Exposition is woven in during
the action, and the falling action is short.

**Best for:** Thrillers, action, horror, survival stories, cliffhanger serials and short
episodes that need to hook immediately.

**Beats:**

| # | Beat | What happens | ~% |
|---|---|---|---|
| 1 | **Immediate Inciting Crisis** | Open in trouble. Backstory is shown only as it becomes necessary. | 0–10 |
| 2 | **Crisis 1** | The first obstacle. The protagonist reacts. | 10–25 |
| 3 | **Breather** | A short pause to reveal character, give exposition and regroup. | 25–30 |
| 4 | **Crisis 2** | A bigger obstacle. The stakes rise. | 30–45 |
| 5 | **Breather** | A shorter pause. Maybe a revelation. | 45–50 |
| 6 | **Crisis 3+** | Keep escalating, with each crisis worse than the last. | 50–80 |
| 7 | **Climax** | The biggest confrontation of all. | 80–95 |
| 8 | **Brief Falling Action** | A short resolution. Get out fast. | 95–100 |

**Example:** *Mad Max: Fury Road*: Max is captured in the first minutes, followed by one
escalating chase after another with short quiet stretches (the night in the bog, the Many
Mothers), ending in the final chase back to the Citadel.

**Pitfalls:**
- Crises that are bigger but not *different*. Each one should change the situation or reveal
  something new.
- No breathers. Without contrast, the intensity goes numb. Pace them in the shots too:
  short, moving shots for a crisis, longer and stiller ones for a breather.
- Characters who are only reacting. Use the breathers to show who they are.

---

### 4.3 In Medias Res (Flashback Structure)

**Origin:** Latin for "into the middle of things" (Horace). It goes back to Homer, since
*The Odyssey* opens late in the journey. The modern TV form opens with a flash-forward ("72
hours earlier…").

**Pitch:** The story opens in the thick of the action or at a late-stage crisis. Once the
hook is set, it jumps back to explain how the characters got there, catches up to the
opening scene (now understood differently) and carries on to the finale.

**Best for:** Hooking an audience fast, mysteries, crime, dramatic irony (we know where it's
heading, but not how), and cold opens.

**Beats:**

| # | Beat | What happens | ~% |
|---|---|---|---|
| 1 | **The Hook** | A vivid, puzzling, high-stakes moment from late in the story. Withhold the context. | 0–5 |
| 2 | **The Jump Back** | A clear time marker ("Three days earlier", a title card, a match cut). | 5–7 |
| 3 | **Build-Up** | The story from an earlier, calmer point. Underneath can be any structure, often three-act. | 7–65 |
| 4 | **Convergence** | The timeline catches up to the opening scene. Replay it with the new understanding: what it *really* meant. | 65–75 |
| 5 | **Continuation & Climax** | Push past the opening moment into the true climax. | 75–95 |
| 6 | **Resolution** | Resolve the aftermath. | 95–100 |

**Example:** *Breaking Bad* pilot: a man in his underwear and a gas mask crashes an RV and
records a goodbye video with a gun in hand (the hook) → "three weeks earlier" he's a mild
chemistry teacher → the build-up → the RV scene again, now understood → the sirens turn out
to be fire trucks, not police.

**Pitfalls:**
- A hook that's just random action. It should raise a specific question ("How did he end up
  here?").
- A convergence that adds nothing. The replayed scene should land differently the second
  time. It can reuse the hook's shots: the same take placed twice in the cut, or new shots
  with the same location, size and camera so the two match.
- Using it to disguise a slow start instead of fixing one.
- An unclear time jump. Make it unmistakable (a card, a change of light or look) so viewers
  don't get lost.

---

## 5. Also worth knowing

### 5.1 The Pixar Story Spine

**Origin:** Kenn Adams, an improv teacher, popularized by Pixar storyboard artist Emma
Coats.

**Pitch:** A fill-in-the-blanks chain of cause and effect. It's very fast to outline with,
and its natural rhythm ("because of that…") suits narration. It pairs well with a Fable
ending.

**Beats:**

| # | Prompt | What it does | ~% |
|---|---|---|---|
| 1 | **Once upon a time…** | The character and the world. | 0–10 |
| 2 | **Every day…** | The routine, the status quo. | 10–20 |
| 3 | **Until one day…** | The disruption. | 20–30 |
| 4 | **Because of that…** | The first consequence. | 30–50 |
| 5 | **Because of that…** | The next consequence (repeat as needed, with each caused by the last). | 50–70 |
| 6 | **Until finally…** | The climax and resolution. | 70–90 |
| 7 | **And ever since then…** | The new normal. | 90–100 |
| (8) | **And the moral is…** | *Optional:* add this when combining with the Fable. | — |

**Example:** *Finding Nemo*: once upon a time there was a widowed fish, Marlin, who was very
protective of his only son, Nemo. Every day, Marlin warned Nemo about the ocean's dangers.
One day, Nemo swam out to sea in defiance. Because of that, he was caught by a diver.
Because of that, Marlin set out across the ocean to find him… Until finally, Marlin and Nemo
found each other and learned that love depends on trust. And ever since then, Marlin has
let Nemo live his own life.

**Pitfalls:** Every "because of that" must actually be *caused* by the previous one. If the
honest link is "and then", the chain is broken.

---

## Combining structures

Structures can be stacked at different levels:

- **Season arc + episode shape:** A season can follow the Hero's Journey (or its 27 beats) or
  the Virgin's Promise while each episode uses the Story Circle, Sitcom or three-act
  structure. Each episode can then map to one or two stages of the season arc.
- **A-plot / B-plot:** Use different structures in parallel. For example, a three-act A-plot
  can carry a Kishōtenketsu B-plot that delivers the thematic twist.
- **Frame + core:** In Medias Res is a *frame*. The section after the jump back still needs
  its own structure (usually three-act or Fichtean).
- **Spine + fable:** The Story Spine gives the cause-and-effect chain, and the Fable gives the
  flaw → consequence → moral.
- **Scene level:** The Story Circle and Kishōtenketsu both scale down to a single scene or
  sequence.

## Choosing by need

| If the user wants… | Suggest |
|---|---|
| A clear lesson for kids, in under 5 minutes | Fable, Story Spine, Cautionary Tale |
| A gentle, conflict-free, wonder-filled piece | Kishōtenketsu |
| A repeatable half-hour comedy | Sitcom Formula |
| A repeatable half-hour with real (small) change | Story Circle |
| A satisfying standalone drama | Three-Act |
| A grounded story about doing the right thing | Parable |
| A big transformation across many episodes | Hero's Journey or its 27 beats (outward), Virgin's Promise (inward) |
| Tragedy, or rise and fall | Freytag's Pyramid |
| Nonstop tension from the first shot | Fichtean Curve |
| An opening hook that grabs immediately | In Medias Res (wrapped around another structure) |
