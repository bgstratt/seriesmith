"""
seriesmith.core — the model-free core.

    story.py           script text -> story IR (and the legacy parser dict)
    ir.py              the IR dataclasses (Episode / Sequence / Shot / Line) and their JSON
    series_config.py   loading series.json, the series config
    speech.py          dialogue pacing: syllables, speech time, forced rate

Nothing here knows about a model: no frame grid, no reference slots, no prompt
format. Those belong to a target (seriesmith/targets/; the default is MiniMax H3, in
targets/video/minimax_h3_ref2va/).
Stdlib only.
"""
