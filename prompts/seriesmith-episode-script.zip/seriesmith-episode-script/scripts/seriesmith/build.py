"""
seriesmith build — script.md + series.json  ->  shots.json (story IR) + shotlist.json

You write a screenplay-flavoured script and the series config (series.json);
this produces each target's shotlist, a list of any reference assets you still
need to make, and a timing report.

    seriesmith build series.json script.md -o <project_root>
    seriesmith build series.json script.md -o <project_root> --proxy
    seriesmith check series.json script.md

It runs in three steps: parse the script into the model-free story IR
(seriesmith.core.story, written to shotlist/shots.json), pick each shot's video target
(targets.episode_targets: the series config's `series.target`, then every
`target:` and `profile:` the script names), and compile each target's shots
with it (`target.compile_episode`). The series target's shots go to
shotlist.json (always written); another target's to shotlist.<target>.json
(`_proxy` likewise), and refs_todo merges what they all need. Everything
model-specific -- the frame grid, reference slots, the prompt format, audio
policy, presets -- is the target's (targets/video/<id>/). This file only
parses, reports and writes.
"""

from __future__ import annotations

import argparse
import os
import re
import sys
from typing import Callable

from seriesmith import targets as TG
from seriesmith.core import framing, ir  # noqa: F401
from seriesmith.core.series_config import (character_ids, load_series_config, profile_styles,
                                           series_info, subject_ids, variant_of)
# Model-neutral pieces, re-exported under their old names: the aligner and
# others import them from here.
from seriesmith.core.ir import stable_seed  # noqa: F401
from seriesmith.core.speech import (GAP_SAME, GAP_SPEAKER, HEAD_AIR, RATE_CEILING,  # noqa: F401
                                    SPEECH_RATE, TAIL_AIR, forced_rate, pacing,
                                    speech_seconds, syllables)
from seriesmith.core.story import (META_KEYS, OS_TOKENS, SIZES, VO_TOKENS,  # noqa: F401
                                   ScriptError, parse_script, parse_story,
                                   split_parenthetical)

# ---------------------------------------------------------------------------
# Compatibility: the H3 names h3pipe's build used to define, now the default
# video target's. The aligner snaps with snap_up and the tests read RETENTIONS
# and legacy_episode; new code should go through a Target instead.
# ---------------------------------------------------------------------------

from seriesmith.targets.video.minimax_h3_ref2va import compile as _h3  # noqa: E402
from seriesmith.core import fileio as F

# Checks for the series config's stage recipes, by block name ("upscale",
# "post"): each takes the block's `master` and returns warnings. Imported only
# when a series config has such a recipe. The script-writing skill carries the
# build without those stages (they need the rest of seriesmith), so there the
# recipe is passed over with a note rather than failing the whole check.
NOT_CHECKED = ("series.json {block}.master isn't checked by this copy of the build "
               "(the skill's); `seriesmith check` checks it")


def _check_upscale(recipe) -> list[str]:
    try:
        from seriesmith import upscale
    except ImportError:
        return [NOT_CHECKED.format(block="upscale")]
    return upscale.check_recipe(recipe)


def _check_post(recipe) -> list[str]:
    try:
        from seriesmith import post
    except ImportError:
        return [NOT_CHECKED.format(block="post")]
    return post.check_recipe(recipe)


RECIPE_CHECKS: dict[str, Callable[[object], list[str]]] = {
    "upscale": _check_upscale, "post": _check_post}

DEFAULT_TARGET = TG.load_target(TG.DEFAULT_VIDEO_TARGET, "video")
snap_up = DEFAULT_TARGET.template.snap
GRID_STEP, GRID_BASE, GRID_MAX = (DEFAULT_TARGET.template.step, DEFAULT_TARGET.template.base,
                                  DEFAULT_TARGET.template.max)
RETENTIONS = _h3.RETENTIONS
RETENTION_DEFAULT = _h3.RETENTION_DEFAULT
RETENTION_OF = _h3.RETENTION_OF
legacy_episode = _h3.legacy_episode
build_prompt = _h3.build_prompt
FINAL_MODEL = DEFAULT_TARGET.presets["final"].model
FINAL_LORA = DEFAULT_TARGET.presets["final"].lora
FINAL_STEPS = DEFAULT_TARGET.presets["final"].steps
PROXY_LORA = DEFAULT_TARGET.presets["proxy"].lora
PROXY_STEPS = DEFAULT_TARGET.presets["proxy"].steps
SIZE_HINT = dict(_h3.RECIPE["size_hints"])


def compile_episode(ep: dict, series_cfg: dict, proxy: bool) -> tuple[dict, dict]:
    """The parser-shaped episode compiled for the default target (the old
    signature; build itself compiles the IR through the episode's target)."""
    return _h3.compile_legacy(DEFAULT_TARGET, ep, series_cfg, "proxy" if proxy else "final")


def compile_groups(story: ir.Episode, series_cfg: dict, pass_: str,
                   groups=None) -> list[tuple[TG.Target, dict, dict]]:
    """[(target, shotlist doc, report)] for one pass: each target the episode
    uses compiles its own shots (TG.episode_targets), the series target first.
    What a build writes and what --check reports (and the editor's check).

    Story warnings -- the ones that are about the script rather than any
    model -- are added to the first report, which is the one `--check` prints
    and the editor reads (source.check_text)."""
    groups = TG.episode_targets(story, series_cfg) if groups is None else groups
    check_story(story, series_cfg)
    built = [(t, *t.compile_episode(story, series_cfg, pass_, only=ids)) for t, ids in groups]
    if built:
        built[0][2]["warnings"] = (list(built[0][2].get("warnings") or [])
                                   + story_warnings(story, series_cfg))
    return built


def check_story(story: ir.Episode, series_cfg: dict) -> None:
    """ValueError for what the script asks of the series config and doesn't get.

    A subject with no `design` is legal -- a character who is only ever a voice
    needs none -- but putting one on screen leaves every prompt writer with
    nothing to say about them, so it is caught here by name rather than deep in
    one as a KeyError."""
    book = series_cfg.get("subjects") or {}
    for sq in story.sequences:
        for sh in sq.shots:
            for sid in list(sh.cast) + list(sh.props):
                e = book.get(sid) or {}
                if not str(e.get("design") or "").strip():
                    raise ValueError(
                        f"shot {sh.id}: '{sid}' is on screen but has no `design` in "
                        f"series.json, so nothing can describe them. Give them one, or "
                        f"keep them off screen: a voice-only character speaks with "
                        f"(V.O.) or (O.S.) and never appears in `who:` or `with:`.")


def story_warnings(story: ir.Episode, series_cfg: dict | None = None) -> list[str]:
    """What the script says that no target can fix.

    One plate is one picture. Two people who each get their own shot in a
    sequence, both built on the same plate, are drawn against the same
    background from the same view: the cut then reads as one camera with
    people appearing and disappearing in it, rather than as a reverse angle.
    Nothing in a prompt undoes that, because the plate is a picture and the
    prompt is words -- it wants an angle per speaker in the series config
    (docs/AUTHORING.md, "A location is one angle, not one place")."""
    # a wardrobe variant is the same person: Dana in a towel and Dana in an
    # afghan taking turns on one plate is one character changing clothes, not
    # two people talking
    variants = variant_of(series_cfg or {})
    book = (series_cfg or {}).get("subjects") or {}

    def person(sid: str) -> str:
        return variants.get(sid, sid)

    def name(sid: str) -> str:
        return (book.get(sid) or {}).get("name", sid)

    out = []
    for sq in story.sequences:
        by_plate: dict[str, list[str]] = {}
        for sh in sq.shots:
            if len(sh.cast) == 1:
                by_plate.setdefault(sh.plate or sq.location, []).append(person(sh.cast[0]))
        for plate, cast in by_plate.items():
            who = sorted(set(cast))
            if len(who) < 2:
                continue
            names = [name(w) for w in who]
            listed = (" and ".join(names) if len(names) == 2
                      else ", ".join(names[:-1]) + " and " + names[-1])
            out.append(
                f"sequence {sq.id}: {listed} each get their own shot on the same plate "
                f"({plate}), so they are drawn against one background from one view and "
                f"the cut reads as a single camera rather than a reverse angle. Give the "
                f"location an angle per speaker and name it with `plate:`.")
    out += jump_cuts(story, person, name)
    # the old forms of `continuous:` (docs/CONTINUOUS.md), read as the new ones
    for sq in story.sequences:
        out += list(getattr(sq, "legacy", None) or [])
        for sh in sq.shots:
            out += list(getattr(sh, "legacy", None) or [])
    mode = ((series_cfg or {}).get("upscale") or {}).get("save_latents")
    if mode is not None and mode not in ("final", "always", "never"):
        out.append(f"series.json upscale.save_latents is {mode!r}: it takes \"final\" (the "
                   f"default), \"always\" or \"never\", so renders use \"final\".")
    for block, check in RECIPE_CHECKS.items():
        if "master" in ((series_cfg or {}).get(block) or {}):
            out += check(series_cfg[block]["master"])
    out += look_light_sources(series_cfg or {})
    return out


# Things that give off light. A look that names them asks every shot to show
# them: a close-up widens its frame to fit the candles in, or invents them
# behind a face (2026-10-25, H3 Omni on one seed: "practical light from the
# windows and candles" kept an extreme close-up a close-up until it went).
LIGHT_SOURCES = re.compile(
    r"\b(windows?|candles?|candlelight|candlesticks?|candelabras?|chandeliers?|lamps?|"
    r"lamplight|lanterns?|sconces?|fireplaces?|firelight|torch(?:es)?|torchlight|"
    r"streetlights?|street lamps?|neon signs?|light ?bulbs?|bulbs?)\b", re.I)


def look_light_sources(series_cfg: dict) -> list[str]:
    """A look (the series' `style.look`, or a profile's `look`) that names
    the things the light comes from: the look opens every shot's prompt it
    covers, so they turn up in every one of them. The light's quality belongs
    in the look; its sources in each location's description (docs/AUTHORING.md,
    "Writing the `look` line")."""
    looks = [("style.look", ((series_cfg.get("style") or {}).get("look") or ""))]
    looks += [(f"profile '{pid}' look", (p or {}).get("look") or "")
              for pid, p in (series_cfg.get("profiles") or {}).items() if isinstance(p, dict)]
    out = []
    for where, look in looks:
        found = sorted({m.group(0).lower() for m in LIGHT_SOURCES.finditer(look)})
        if found:
            out.append(
                f"series.json {where} names light sources ({', '.join(found)}): the look opens "
                f"every shot's prompt, so each one is asked to show them, and a close-up widens "
                f"to fit them in or invents them behind a face. Say the light's quality in the "
                f"look (\"low-key practical light, pools of light and deep soft shadow\") and "
                f"where it comes from in each location's description.")
    return out


def jump_cuts(story: ir.Episode, person, name) -> list[str]:
    """Consecutive shots of a sequence that would cut as a jump cut: the same
    people, on the same plate, at sizes less than two steps apart. Each shot is
    generated on its own, so the second re-poses everyone in place rather than
    continuing the first, and the cut reads as people jerking or appearing.
    A continuous sequence chains its shots on purpose, and a shot opening on
    the previous one's last frame (`first: continuity`) continues it, so
    neither is a jump cut. A warning, not an error: the action may still carry
    the cut (a cut on movement), which the script fields can't show
    (docs/AUTHORING.md, "Cutting within a location")."""
    out = []
    for sq in story.sequences:
        if sq.continuous:
            continue
        for a, b in zip(sq.shots, sq.shots[1:]):
            # continuing the shot before is no cut at all: `continuous: first | latent`
            # (or the old `first: continuity`)
            if b.continues(sq) or (b.keyframe("first", sq) or "").strip().lower() == "continuity":
                continue
            who_a = {person(s) for s in a.cast}
            if not who_a or who_a != {person(s) for s in b.cast}:
                continue
            plate = a.plate or sq.location
            if plate != (b.plate or sq.location):
                continue
            apart = framing.steps_apart(a.size, b.size)
            if apart is None or apart >= 2:
                continue
            names = sorted(name(w) for w in who_a)
            listed = (names[0] if len(names) == 1 else
                      " and ".join(names) if len(names) == 2 else
                      ", ".join(names[:-1]) + " and " + names[-1])
            sizes = (f"two {framing.term(a.size)}s" if apart == 0 else
                     f"a {framing.term(a.size)} and a {framing.term(b.size)}")
            out.append(
                f"sequence {sq.id}: {a.id} -> {b.id} cuts between {sizes} of {listed} on the "
                f"same plate ({plate}): a jump cut, everyone re-posed in place. Change the size "
                f"by two or more steps, give {b.id} another `plate:`, or put a cutaway between "
                f"them (docs/AUTHORING.md, \"Cutting within a location\").")
    return out


# ---------------------------------------------------------------------------

def mmss(sec: float) -> str:
    m, s = divmod(sec, 60)
    return f"{int(m)}:{s:05.2f}"


def render_todo(report: dict, root: str) -> str:
    """The asset work order.

    Every prompt here is built from the series config, so the wording that describes a
    character in their sheet prompt is the exact wording that goes into all of
    their shot prompts. Generating from a paraphrase is how a character ends up
    subtly wrong in every shot.
    """
    need = report["needed"]
    # the size each kind of ref should be made at: the target recipe's
    hints = report.get("size_hints", SIZE_HINT)
    missing = [(p, v) for p, v in need.items()
               if not os.path.isfile(os.path.join(root, p))]
    have = len(need) - len(missing)
    blocked = report.get("blocked_shots", {})

    lines = [f"# Asset work order — {report['episode']} {report['title']}", "",
             f"{have}/{len(need)} on disk. Generate each missing asset, save it to the "
             f"path shown, then re-run seriesmith build.", ""]
    if not missing:
        lines += ["Everything the episode needs is already on disk.", ""]
        return "\n".join(lines)

    lines += ["| # | Path | Kind | Size hint | Shots blocked |",
              "|---|---|---|---|---|"]
    for i, (path, v) in enumerate(missing, start=1):
        lines.append(f"| {i} | `{path}` | {v['kind']} | "
                     f"{hints.get(v['kind'], '—')} | {len(blocked.get(path, []))} |")
    lines += ["", "---", ""]

    for i, (path, v) in enumerate(missing, start=1):
        sh = blocked.get(path, [])
        lines += [f"## {i}. `{path}`",
                  f"**{v['kind']}** · size hint {hints.get(v['kind'], 'see prompt')}"
                  + (f" · blocks {len(sh)} shot(s): {', '.join(sh[:8])}"
                     f"{' …' if len(sh) > 8 else ''}" if sh else ""), "",
                  "```", v["prompt"].strip(), "```", ""]
    return "\n".join(lines)


def print_report(r: dict, root: str) -> None:
    print(f"\n  {r['episode']}  {r['title']}   [{r['mode']}]  "
          f"{r['resolution']}  {r['steps']} steps")
    print(f"  model        {r.get('model', '')}")
    print(f"  lora         {r.get('lora', '')}")
    print(f"  {'-' * 60}")
    print(f"  {r['sequences']} sequences, {r['shots']} shots")
    print(f"  runtime      {mmss(r['delivered_s'])}  "
          f"(scripted {mmss(r['target_s'])}, +{r['pad_frames']}f grid pad)")
    print(f"  audio        " + ", ".join(f"{n}x {p}" for p, n in r["policies"].items()))
    missing = [p for p in r["needed"] if not os.path.isfile(os.path.join(root, p))]
    have = len(r["needed"]) - len(missing)
    print(f"  references   {have}/{len(r['needed'])} on disk"
          + (f", {len(missing)} to make" if missing else ""))
    for w in r["warnings"]:
        print(f"    ! {w}")
    print()


def shot_pacing(shot, default_pace: str, snap, fps: float = 24.0) -> dict | None:
    """One dialogue shot measured against the rate it forces on the delivery,
    in the window its target renders (`snap`: its frame grid): {"held",
    "syllables", "rate", "fits", "verdict" (ok | tight | CRAMMED), "pace"}, or
    None for a shot without dialogue. The `--pace` report and the shot form's
    meter."""
    dialogue = [{"who": d.speaker, "line": d.line} for d in shot.dialogue]
    if not dialogue:
        return None
    pace = shot.pace or default_pace
    t = shot.timing or {}
    if "audio_in" in t:
        dur = t["audio_out"] - t["audio_in"]
    elif t.get("auto") or t.get("model"):
        # `dur: model`: the build's estimate is the dialogue's length
        dur = speech_seconds(dialogue, pace)
    else:
        dur = t.get("seconds", 0.0)
    held = snap(max(1, round(dur * fps))) / fps
    syl, _ = pacing(dialogue)
    rate = forced_rate(dialogue, held)
    fits = snap(max(1, round(speech_seconds(dialogue, pace) * fps))) / fps
    if rate > RATE_CEILING:
        verdict = "CRAMMED"
    elif rate > SPEECH_RATE[pace] + 0.15:
        verdict = "tight"
    else:
        verdict = "ok"
    return {"held": held, "syllables": syl, "rate": rate, "fits": fits, "verdict": verdict,
            "pace": pace, "pace_rate": SPEECH_RATE[pace], "ceiling": RATE_CEILING}


def print_pacing(story: ir.Episode, series_cfg: dict, fps: float = 24.0,
                 template: TG.Template | None = None,
                 templates: dict[str, TG.Template] | None = None) -> int:
    """Every dialogue shot measured against the rate it forces on the delivery,
    in the window the target will actually render (`template`, or per shot
    `templates` in an episode that mixes targets)."""
    default_snap = (template or DEFAULT_TARGET.template).snap
    default = series_cfg.get("speech", {}).get("pace", "normal")
    rows, crammed, tight, gain = [], 0, 0, 0.0
    for seq in story.sequences:
        for shot in seq.shots:
            snap = (templates[shot.id].snap if templates and shot.id in templates
                    else default_snap)
            p = shot_pacing(shot, default, snap, fps)
            if p is None:
                continue
            held, syl, rate, fits, verdict = (p["held"], p["syllables"], p["rate"], p["fits"],
                                              p["verdict"])
            if verdict == "CRAMMED":
                mark = "!!"
                crammed += 1
                gain += fits - held
            elif verdict == "tight":
                mark = " !"
                tight += 1
                gain += max(0.0, fits - held)
            else:
                mark = "  "
            rows.append((mark, shot.id, held, syl, rate, fits, verdict))

    if not rows:
        print("\n  no dialogue in this episode.\n")
        return 0
    print(f"\n  {'shot':10} {'held':>6} {'syl':>4} {'forced':>7} {'fits':>6}  verdict")
    print("  " + "-" * 52)
    for mark, sid, held, syl, rate, fits, verdict in rows:
        print(f"{mark}{sid:10} {held:6.2f} {syl:4} {rate:7.1f} {fits:6.2f}  {verdict}")
    print(f"\n  {crammed} crammed, {tight} tight, {len(rows) - crammed - tight} ok "
          f"of {len(rows)} dialogue shots")
    print(f"  pace '{default}' = {SPEECH_RATE[default]} syl/s, ceiling {RATE_CEILING}")
    if gain > 0:
        print(f"  giving every one of them room adds {gain:.2f}s of runtime")
    print("\n  Fix by lengthening (`dur:` or `dur: auto`), cutting syllables, or\n"
          "  splitting the shot. `pace: fast` marks a rush that is deliberate.\n")
    return 0


def main(argv: list[str] | None = None, prog: str | None = None) -> int:
    ap = argparse.ArgumentParser(prog=prog, description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("series", help="the series config, e.g. series.json")
    ap.add_argument("script", help="the episode script, e.g. ep01.md")
    ap.add_argument("-o", "--out", default=".", help="project root (where shotlist/ lives)")
    ap.add_argument("--proxy", action="store_true", help="emit the low-res animatic pass")
    ap.add_argument("--check", action="store_true", help="validate and report, write nothing")
    ap.add_argument("--pace", action="store_true",
                    help="report dialogue pacing per shot and write nothing")
    args = ap.parse_args(argv)
    # a show's own targets (<show>/targets/<id>/target.json) count for this
    # build: `target:` lines and profiles may name them (Phase 12)
    TG.add_thread_root(args.out)

    try:
        # the series config first, and on its own, so a problem in it is
        # reported against series.json rather than against the script
        try:
            series_cfg = load_series_config(args.series)
        except ValueError as exc:
            print(f"\n  error in {os.path.basename(args.series)}: {exc}\n", file=sys.stderr)
            return 1
        with open(args.script, encoding="utf-8") as fh:
            # parse -> story IR
            story = parse_story(fh.read(), subject_ids(series_cfg), character_ids(series_cfg),
                                series_info(series_cfg), variant_of(series_cfg),
                                profile_styles(series_cfg))
        # -> the video target each shot renders on (profiles and target:
        # lines checked here) -> each target compiles its own shots
        groups = TG.episode_targets(story, series_cfg)
        target = groups[0][0]
        if args.pace:
            per_shot = {sid: t.template for t, ids in groups[1:] for sid in ids}
            return print_pacing(story, series_cfg, template=target.template,
                                templates=per_shot)
        built = compile_groups(story, series_cfg, "proxy" if args.proxy else "final", groups)
        _, doc, report = built[0]
    except (ScriptError, ValueError, KeyError) as exc:
        print(f"\n  error in {os.path.basename(args.script)}: {exc}\n", file=sys.stderr)
        return 1
    except FileNotFoundError as exc:
        print(f"\n  {exc}\n", file=sys.stderr)
        return 1

    print_report(report, args.out)
    for t, _, rep in built[1:]:
        print(f"  target {t.id} ({t.short}): {rep['shots']} shot(s) of this episode")
        print_report(rep, args.out)
    if len(built) > 1:
        # one work order for the episode: every target's refs, the series
        # target's first (a later target only adds what it alone needs)
        report = dict(report, needed=dict(report["needed"]),
                      blocked_shots={k: list(v) for k, v in report["blocked_shots"].items()},
                      size_hints=dict(report.get("size_hints", SIZE_HINT)))
        for _, _, rep in built[1:]:
            for p, v in rep["needed"].items():
                report["needed"].setdefault(p, v)
            for p, ids in rep.get("blocked_shots", {}).items():
                have = report["blocked_shots"].setdefault(p, [])
                have += [i for i in ids if i not in have]
            for k, v in (rep.get("size_hints") or {}).items():
                report["size_hints"].setdefault(k, v)
    if args.check:
        return 0

    os.makedirs(os.path.join(args.out, "shotlist"), exist_ok=True)

    # One shotlist per pass for the series target, and one per other target
    # that some shot renders on (shotlist.<target>[_proxy].json).
    sfx = "_proxy" if args.proxy else ""
    sl = os.path.join(args.out, "shotlist", f"shotlist{sfx}.json")
    written = [sl]
    F.write_json(sl, doc, end="")
    for t, tdoc, _ in built[1:]:
        p = os.path.join(args.out, "shotlist", f"shotlist.{t.id}{sfx}.json")
        F.write_json(p, tdoc, end="")
        written.append(p)
    # a target no shot uses any more leaves no stale file behind
    keep = {os.path.basename(p) for p in written}
    for n in os.listdir(os.path.join(args.out, "shotlist")):
        if (n.startswith("shotlist.") and n.endswith(f"{sfx}.json") and n not in keep
                and (args.proxy or not n.endswith("_proxy.json"))):
            os.remove(os.path.join(args.out, "shotlist", n))
    # The story IR: model-free and pass-free, so both passes write the same file.
    ir_path = os.path.join(args.out, "shotlist", "shots.json")
    F.write_json(ir_path, story.to_json(), end="")
    # Suffix the proxy's work order the way the shotlist is suffixed. A proxy
    # pass can legitimately need fewer assets (generated voices need no
    # samples), and letting it overwrite the canonical list would quietly drop
    # items the final pass still requires.
    sfx = "_proxy" if args.proxy else ""
    todo = os.path.join(args.out, f"refs_todo{sfx}.md")
    F.write_text(todo, render_todo(report, args.out))

    # machine-readable twin, for driving a batch image run
    todo_json = os.path.join(args.out, f"refs_todo{sfx}.json")
    F.write_json(todo_json, [
            {"path": p, "kind": v["kind"], "prompt": v["prompt"],
             "size_hint": report.get("size_hints", SIZE_HINT).get(v["kind"], ""),
             "exists": os.path.isfile(os.path.join(args.out, p)),
             "blocks_shots": report.get("blocked_shots", {}).get(p, [])}
            for p, v in report["needed"].items()
        ], end="")

    for p in written:
        print(f"  -> {p}")
    print(f"  -> {ir_path}")
    print(f"  -> {todo}")
    print(f"  -> {todo_json}\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
