"""Check an episode script against its series config with the build bundled
beside this file (seriesmith/build.py): python check.py series.json ep01.md --check"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from seriesmith import build  # noqa: E402

raise SystemExit(build.main(sys.argv[1:], prog="check.py"))
